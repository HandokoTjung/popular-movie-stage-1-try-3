package id.co.blogspot.httphanpalmbridge.popularmovietry3;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static android.R.attr.description;

/**
 * Created by Handoko on 7/5/2017.
 */

public class jsonGenerator {


    //movieJsonStr adalah Json data dari website
    public static String[] getSimpleJson(Context context, String movieJsonStr)
            throws JSONException {

        String[] parsedMovieData = null; //untuk menghold data masing2 film
        //buat Json object dulu
        JSONObject movie = new JSONObject(movieJsonStr);
        JSONArray movieArray = movie.getJSONArray("result");
        //buat Json array dari Json object yang sudah dibuat dengan nama array result
        //variable parsedmoviedata diisi oleh data dari array string
        parsedMovieData = new String[movieArray.length()];

            for (int i = 0; i < movieArray.length(); i++) {
            String movieTitle;
            String moviePoster;
            String movieRelease;
            String movieVoteAvg;
            String moviePlot;


            JSONObject movieUrutanKeI = movieArray.getJSONObject(i);

            movieTitle = movieUrutanKeI.getString("title");

            moviePoster = "https://image.tmdb.org/t/p/w500/"+ movieUrutanKeI.getString("poster_path");

            movieRelease = movieUrutanKeI.getString("release_date");

            movieVoteAvg = movieUrutanKeI.getString("vote_average");

            moviePlot = movieUrutanKeI.getString("overview");

//            https://image.tmdb.org/t/p/w500/kqjL17yufvn9OVLyXYpvtyrFfak.jpg


            parsedMovieData[i] = moviePoster;


//                    "Judul : " + movieTitle +
//                    " - Poster :" + moviePoster +
//                    " - Tanggal Release :" + movieRelease +
//                    " - Vote Rank :" + movieVoteAvg +
//                    " - Sinopsis :" + moviePlot
            ;

        }
        return parsedMovieData;

    }
}
