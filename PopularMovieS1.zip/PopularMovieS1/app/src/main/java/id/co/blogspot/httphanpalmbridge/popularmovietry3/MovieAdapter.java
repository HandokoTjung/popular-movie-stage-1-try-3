package id.co.blogspot.httphanpalmbridge.popularmovietry3;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import static id.co.blogspot.httphanpalmbridge.popularmovietry3.NetworkUtils.GITHUB_BASE_URL;
import static id.co.blogspot.httphanpalmbridge.popularmovietry3.NetworkUtils.PARAM_LANGUAGE;
import static id.co.blogspot.httphanpalmbridge.popularmovietry3.NetworkUtils.PARAM_PAGE;
import static id.co.blogspot.httphanpalmbridge.popularmovietry3.NetworkUtils.PARAM_QUERY;
import static id.co.blogspot.httphanpalmbridge.popularmovietry3.NetworkUtils.apikey;
import static id.co.blogspot.httphanpalmbridge.popularmovietry3.NetworkUtils.language;
import static id.co.blogspot.httphanpalmbridge.popularmovietry3.NetworkUtils.pageno;

/**
 * Created by Handoko on 7/4/2017.
 */



public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {
    private String[] mMovieItems;
    private Context context;

    public MovieAdapter() {
    }

    public class MovieViewHolder extends RecyclerView.ViewHolder {

        public final ImageView listItemMovieView;
        public MovieViewHolder(View view) {
            super(view);
            listItemMovieView = (ImageView) view.findViewById(R.id.tv_item_movie);
        }
    }

    @Override
    public MovieViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        Context context = viewGroup.getContext();
        int layoutIdForListItem = R.layout.movie_list_item;
        LayoutInflater inflater = LayoutInflater.from(context);
        boolean shouldAttachToParentImmediately = false;

        View view = inflater.inflate(layoutIdForListItem, viewGroup, shouldAttachToParentImmediately);
        return new MovieViewHolder(view);
    }
    @Override
    public void onBindViewHolder(MovieViewHolder holder, int position) {
        String moviePoster = mMovieItems[position];

        //taro picasso disini

        Picasso.with(context).load(moviePoster).into(holder.listItemMovieView);


      //  holder.listItemMovieView.setText(moviePlaying);
    }
    @Override
    public int getItemCount() {
        if (null == mMovieItems) return 0;
        return mMovieItems.length;
    }

    public void setMovieItems(String[] movieData) {
        mMovieItems = movieData;
        notifyDataSetChanged();
    }


}

