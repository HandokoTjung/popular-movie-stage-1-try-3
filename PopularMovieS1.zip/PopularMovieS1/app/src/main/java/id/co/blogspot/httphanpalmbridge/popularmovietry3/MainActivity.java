package id.co.blogspot.httphanpalmbridge.popularmovietry3;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private MovieAdapter mMovieAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRecyclerView = (RecyclerView) findViewById(R.id.rv_movies);


        LinearLayoutManager layoutManager
                = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        // COMPLETED (41) Set the layoutManager on mRecyclerView
        mRecyclerView.setLayoutManager(layoutManager);
        // COMPLETED (42) Use setHasFixedSize(true) on mRecyclerView to designate that all items
        // in the list will have the same size
        mRecyclerView.setHasFixedSize(true);
        // COMPLETED (43) set mForecastAdapter equal to a new ForecastAdapter
        mMovieAdapter = new MovieAdapter();
        // COMPLETED (44) Use mRecyclerView.setAdapter and pass in mForecastAdapter
        mRecyclerView.setAdapter(mMovieAdapter);


        loadMovieData();
    }

    private void loadMovieData() {
       URL githubSearchUrl = NetworkUtils.buildUrl();
        //String searchUrlString = githubSearchUrl.toString();
        new GithubQueryTask().execute(githubSearchUrl); //memanggil background apps untuk mengembalikan data json dari website
    }


    // COMPLETED (1) Create a class called GithubQueryTask that extends AsyncTask<URL, Void, String>
    public class GithubQueryTask extends AsyncTask<URL, Void, String[]> {

        // COMPLETED (2) Override the doInBackground method to perform the query. Return the results. (Hint: You've already written the code to perform the query)
        @Override
        protected String[] doInBackground(URL... params) {
            URL movieUrl = params[0];
            try {
                String httpResponse = NetworkUtils.getResponseFromHttpUrl(movieUrl);
                String[] arrayMovieData = jsonGenerator.getSimpleJson(MainActivity.this, httpResponse);
                return arrayMovieData;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        // COMPLETED (3) Override onPostExecute to display the results in the TextView
        @Override
        protected void onPostExecute(String[] mMovieData) {
            if (mMovieData != null) {
                mMovieAdapter.setMovieItems(mMovieData);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemThatWasClickedId = item.getItemId();
        if (itemThatWasClickedId == R.id.action_search) {
//            makeGithubSearchQuery();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
